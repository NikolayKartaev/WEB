function greeting(yourName) {
    console.log (`Здравствуйте, дорогой ${yourName}!`);
}

greeting(prompt("Введите ваше имя:"));