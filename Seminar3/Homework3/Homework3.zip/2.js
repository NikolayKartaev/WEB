function greeting(name) {
    console.log(`Привет, ${name}`);
}

const user_name = prompt("Введите ваше имя:");   
greeting(user_name);
